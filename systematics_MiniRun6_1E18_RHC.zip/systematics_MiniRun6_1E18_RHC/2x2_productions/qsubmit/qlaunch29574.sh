#!/bin/bash
#PBS -l select=1:ncpus=1
#PBS -l walltime=1:60:00
#PBS -l filesystems=home:grand:eagle
#PBS -A ALCF_for_DUNE
#PBS -q debug

export http_proxy="http://proxy:3128"
export https_proxy="http://proxy:3128"

#remove export PMI_NO_FORK=1
export BALSAM_SITE_PATH=/home/aleena/2x2_productions
cd $BALSAM_SITE_PATH

echo "Starting balsam launcher at $(date)"
/home/aleena/env2/bin/python /home/aleena/env2/lib/python3.11/site-packages/balsam/cmdline/launcher.py -j mpi -t 58  \
 --tag workflow=MiniRun6_1E18_RHC_Birks_A_1sig_up_Systematics_stage2_analysis_v0  \

echo "Balsam launcher done at $(date)"