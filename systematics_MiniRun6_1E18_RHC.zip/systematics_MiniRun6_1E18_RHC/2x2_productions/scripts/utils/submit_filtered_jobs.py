site_name = "2x2_productions"
name = "MiniRun6_1E18_RHC_Birks_A_1sig_up_Systematics"
app_id = "larnd"
version = "v0"
queue= "prod"
project = "ALCF_for_DUNE"


from balsam.api import Job, BatchJob, Site

def submit_filtered_jobs(app_id, num_nodes=32, wall_time_min = 30):

    site = Site.objects.get(site_name)

    BatchJob.objects.create(
        num_nodes=num_nodes,
        wall_time_min=wall_time_min,
        queue=queue,
        project=project,
        site_id=site.id,
        #filter_tags={"workflow": "MiniRun6_1E18_RHC_Birks_A_1sig_up_Systematics_larnd_v0"},
        job_mode="mpi"
    )

submit_filtered_jobs(app_id)
