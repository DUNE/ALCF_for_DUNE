from balsam.api import ApplicationDefinition, BatchJob, Job, Site
import yaml

#Machine variables
#########################
queue = "debug"          #
project="ALCF_for_DUNE" #
job_mode="mpi"          #
#########################

#build larndsim again in the venv after changing the constant

#release of jobs
#first 16 jobs,
#then 10 jobs of 128 each

#need to filter/tag submit index for jobs while submitting otherwise balsam submits
#all of the jobs 

#default prod
cpu_packing_count = 2
#need to experiment with this as we have 1024 jobs
gpu_packing_count = 2

if queue == "debug":
    cpu_packing_count = 1 # 2 for debug if submitting more that 1 jobs

name = 'MiniRun6_1E18_RHC_Birks_A_1sig_up_Systematics_stage2'

site_name = "2x2_productions"

#runs = ["flow2supera","spine","caf","submit_all_cpu"]
runs = ["caf","submit_all_cpu"]

# Birks_Ab = 0.800+/-2.5%
#v0 Birks_Ab = 0.8+(+1*0.025*0.8)=0.82  //1 Sigma up 
#v1 Birks_Ab = 0.8+(-1*0.025*0.8)=0.78  //1 Sigma down

version = "v0"

"""
Functions
"""

begin_index = 71 #45  #39
spill_size = 2 #10 #32        #32
end_index = 73 #55  #44 #127        #128
wall_time_min = 30 #20
num_nodes = 2  #10  #32        #32


def create_jobs(app_id, size, node_packing_count):

    for i in range(size):
        Job.objects.create( app_id=app_id,
                            site_name=site_name,
                            workdir=f"workdir/{version}_{i}_{app_id}",
                            node_packing_count=node_packing_count,
                            tags={"workflow": f"{name}_{app_id}_{version}", "index":f"{i}"},
                            data={"i": i})

def create_single_dependent_job(app_id, i, parent_ids, node_packing_count, start):

    Job.objects.create( app_id=app_id,
                        site_name=site_name,
                        workdir=f"workdir/{version}_{i}_{app_id}",
                        node_packing_count=node_packing_count,
                        tags={"workflow": f"{name}_{app_id}_{version}", "index":f"{i}", "job_start":f"{start}"},
                        data={"i": i},
                        parent_ids=parent_ids)

def submit_filtered_jobs(app_id, num_nodes=1, wall_time_min = 60):

    site = Site.objects.get(site_name)

    BatchJob.objects.create(
        num_nodes=num_nodes,
        wall_time_min=wall_time_min,
        queue=queue,
        project=project,
        site_id=site.id,
        filter_tags={"workflow": f"{name}_{app_id}_{version}"},
        job_mode=job_mode
    )

def submit_all_jobs(num_nodes=1, wall_time_min = 60):

    site = Site.objects.get(site_name)

    # for start in range(begin_index, end_index, 128):
    for start in range(begin_index, end_index, spill_size):
        BatchJob.objects.create(
            num_nodes=num_nodes,
            wall_time_min=wall_time_min,
            queue=queue,
            project=project,
            site_id=site.id,
            #filter_tags={"workflow": f"{name}_{app_id}_{version}"},
             filter_tags={"job_start":f"{start}"},
            job_mode=job_mode
        )

if "flow2supera" in runs or "all" in runs:

    site = Site.objects.get(site_name)

    # parent_job_ids = [job.id for job in Job.objects.filter(
    #     site_id=site.id, 
    #     tags={"workflow": f"{name}_convert2h5_{version}"},
    #     )]

    #no parents for systematics
    parent_job_ids = []

    #GPU memory exceed error for larnd single run therefore node packing = 1
    for start in range(begin_index, end_index, spill_size):
        for i in range(start, start+spill_size):
            if i < end_index:
                create_single_dependent_job("flow2supera", i, parent_job_ids, cpu_packing_count, start)

    print("flow2supera jobs created")

# if "submit_all_gpu" in runs:
#     # submit_all_jobs(num_nodes = spill_size//cpu_packing_count)
#     submit_all_jobs(num_nodes = min(spill_size, max_nodes), wall_time_min=360)

if "spine" in runs or "all" in runs:

    site = Site.objects.get(site_name)

    #node packing
    for start in range(begin_index, end_index, spill_size):
        for i in range(start, start+spill_size):
            if i < end_index:
                parent_job_ids = [job.id for job in Job.objects.filter(
                site_id=site.id,
                tags={"workflow": f"{name}_flow2supera_{version}", "index":f"{i}"},
                )]
                parent_job_ids = []
                create_single_dependent_job("spine", i, parent_job_ids, gpu_packing_count, start)

    print("spine jobs created")

if "caf" in runs or "all" in runs:

    site = Site.objects.get(site_name)

    #node packing
    for start in range(begin_index, end_index, spill_size):
        for i in range(start, start+spill_size):
            if i < end_index:
                parent_job_ids = [job.id for job in Job.objects.filter(
                site_id=site.id,
                tags={"workflow": f"{name}_spine_{version}", "index":f"{i}"},
                )]
                parent_job_ids = []
                create_single_dependent_job("caf", i, parent_job_ids, cpu_packing_count, start)

    print("caf jobs created")


if "inference" in runs or "all" in runs:

    site = Site.objects.get(site_name)

    #node packing
    for start in range(begin_index, end_index, spill_size):
        for i in range(start, start+spill_size):
            if i < end_index:
                # parent_job_ids = [job.id for job in Job.objects.filter(
                # site_id=site.id, 
                # tags={"workflow": f"{name}_flow2supera_{version}", "index":f"{i}"},
                # )]
                parent_job_ids = []
                create_single_dependent_job("inference", i, parent_job_ids, gpu_packing_count, start)

    print("inference jobs created")

if "analysis" in runs or "all" in runs:

    site = Site.objects.get(site_name)

    #node packing
    for start in range(begin_index, end_index, spill_size):
        for i in range(start, start+spill_size):
            if i < end_index:
                parent_job_ids = [job.id for job in Job.objects.filter(
                site_id=site.id, 
                tags={"workflow": f"{name}_inference_{version}", "index":f"{i}"},
                )]
                parent_job_ids = []
                create_single_dependent_job("analysis", i, parent_job_ids, cpu_packing_count, start)
            
    print("analysis jobs created")

#submit cpu jobs
if "submit_all_cpu" in runs:
    # submit_all_jobs(num_nodes = spill_size//cpu_packing_count)
    # submit_all_jobs(num_nodes = min(spill_size//cpu_packing_count,max_nodes), wall_time_min = 60)
    submit_all_jobs(num_nodes = num_nodes, wall_time_min = wall_time_min)





