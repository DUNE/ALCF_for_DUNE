from balsam.api import ApplicationDefinition, BatchJob, Job, Site
import yaml

'''
MiniRun6 1E18 Birks A Systematics stage2
'''

name = 'MiniRun6_1E18_RHC_Birks_A_1sig_down_Systematics_stage2'
yaml_dir = f'../../specs/{name}/{name}'

site_name = "2x2_productions"
path_2x2 = f"/home/aleena/2x2_sim_111424/2x2_sim"

"""
Functions
"""

def get_env_from_yaml(extension):
    yaml_file_path = f'{yaml_dir}{extension}'
    with open(yaml_file_path, 'r') as file:
        yaml_content = file.read()
    yaml_dict = yaml.safe_load(yaml_content)
    env = yaml_dict['base_envs'][0]['env']
    return env


extension = ".flow2supera.yaml"
env = get_env_from_yaml(extension)
app_id = "MiniRun6_Systematics_flow2supera"

class flow2supera(ApplicationDefinition):
    site = site_name
    print(env)
    environment_variables = env
    
    command_template = "./run_flow2supera.sh"

    def shell_preamble(self):
        return f'''
        export ARCUBE_INDEX={self.job.data["i"]}
        module use /soft/modulefiles
        module load spack-pe-base/0.6.1
        module load apptainer
        cd {path_2x2}/run-mlreco
        export SINGULARITY_BIND=$ARCUBE_DIR,/grand/ALCF_for_DUNE:/grand/ALCF_for_DUNE
        '''

flow2supera.sync()


extension = ".spine.yaml"
env = get_env_from_yaml(extension)
app_id = "MiniRun6_Systematics_spine"

class spine(ApplicationDefinition):
    site = site_name
    print(env)
    environment_variables = env

    command_template = "./run_spine.sh"

    def shell_preamble(self):
        return f'''
        export ARCUBE_INDEX={self.job.data["i"]}
        module use /soft/modulefiles
        module load spack-pe-base/0.6.1
        module load apptainer
        cd {path_2x2}/run-mlreco
        export SINGULARITY_BIND=$ARCUBE_DIR,/grand/ALCF_for_DUNE:/grand/ALCF_for_DUNE
        '''
spine.sync()


extension = ".caf.yaml"
env = get_env_from_yaml(extension)
app_id = "MiniRun6_Systematics_caf"

class caf(ApplicationDefinition):
    site = site_name
    print(env)
    environment_variables = env

#    command_template = "./run_cafmaker.sh"
    command_template = "./cvmfsexec/cvmfsexec config-osg.opensciencegrid.org dune.opensciencegrid.org fermilab.opensciencegrid.org larsoft.opensciencegrid.org dune.osgstorage.org -- ./run_cafmaker.sh"


##fardetector same as this
    def shell_preamble(self):
        return f'''
        export ARCUBE_INDEX={self.job.data["i"]}
        module use /soft/modulefiles
        module load spack-pe-base/0.6.2
        module load apptainer
        module use /soft/modulefiles ; module load conda; conda activate base
        cd {path_2x2}/run-cafmaker
        export SINGULARITY_BIND=$ARCUBE_DIR,/grand/ALCF_for_DUNE:/grand/ALCF_for_DUNE,$CVMFS_PATH/dist/cvmfs:/cvmfs,/opt/nvidia/hpc_sdk/Linux_x86_64/23.9:/opt/cuda
        '''

caf.sync()

'''
extension = ".inference.yaml"
env = get_env_from_yaml(extension)
app_id = "MiniRun6_Systematics_mlreco_inference"

class inference(ApplicationDefinition):
    site = site_name
    print(env)
    environment_variables = env
    
    command_template = "./run_mlreco_inference.sh"

    def shell_preamble(self):

#        return f'''
#        export ARCUBE_INDEX={self.job.data["i"]}
#        module use /soft/modulefiles
#        module load spack-pe-base
#        module load apptainer
#        cd {path_2x2}/run-mlreco
#        '''
'''
inference.sync()


extension = ".analysis.yaml"
env = get_env_from_yaml(extension)
app_id = "MiniRun6_Systematics_mlreco_analysis"

class analysis(ApplicationDefinition):
    site = site_name
    print(env)
    environment_variables = env
    
    command_template = "./run_mlreco_analysis.sh"

    def shell_preamble(self):
        return f'''
#        export ARCUBE_INDEX={self.job.data["i"]}
#        module use /soft/modulefiles
#        module load spack-pe-base
#        module load apptainer
#        cd {path_2x2}/run-mlreco
        
#analysis.sync()



